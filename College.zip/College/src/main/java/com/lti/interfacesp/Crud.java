package com.lti.interfacesp;

public interface Crud {

	public void insert();
	public void delete();
	public void retreive();
	public void update();
	
	
	
}

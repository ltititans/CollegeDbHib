package com.lti.college.College;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="department")
public class Department {
	
	@Id
	
	
	@Column(name="dno")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="somesequenceName2")
	@SequenceGenerator(name="somesequenceName2",sequenceName="orde",allocationSize=1)
	private int dno;
	public Department() {
		super();
	}
	private String dname;
	private String dloc;
	public Department(int dno, String dname, String dloc) {
		super();
		this.dno = dno;
		this.dname = dname;
		this.dloc = dloc;
	}
	public Department(String dname, String dloc) {
		super();
		this.dname = dname;
		this.dloc = dloc;
	}
	public int getDno() {
		return dno;
	}
	public void setDno(int dno) {
		this.dno = dno;
	}
	@Column(name="dname")
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	@Column(name="dloc")
	public String getDloc() {
		return dloc;
	}
	public void setDloc(String dloc) {
		this.dloc = dloc;
	}
	@Override
	public String toString() {
		return "Department [dno=" + dno + ", dname=" + dname + ", dloc=" + dloc + "]";
	}
	
	
	
	
	

}

package com.lti.college.College;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.lti.implc.DepartmentImpl;
import com.lti.implc.InstructorImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	DepartmentImpl d=new DepartmentImpl();
    	d.insert();
    	d.retreive();
//    	d.update();
//    	d.delete();
    	InstructorImpl i=new InstructorImpl();
    	i.insert();
    	i.retreive();
    	i.update();
    	i.delete();
    }
}

package com.lti.college.College;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="instructor")
public class Instructor {
	
	@Id
	@Column(name="i_id")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="somesequenceName2")
	@SequenceGenerator(name="somesequenceName2",sequenceName="orde",allocationSize=1)
	private int i_id;
	public int getI_id() {
		return i_id;
	}

	public void setI_id(int i_id) {
		this.i_id = i_id;
	}
	private String iname;
	private int rno;
	private Department dept;
	public Instructor(String iname, int rno, Department dept) {
		super();
		this.iname = iname;
		this.rno = rno;
		this.dept = dept;
	}
	
	
    public Instructor() {
		super();
	}

	@Column(name="iname")
	public String getIname() {
		return iname;
	}

	public void setIname(String iname) {
		this.iname = iname;
	}
    @Column(name="rno")
	public int getRno() {
		return rno;
	}

	public void setRno(int rno) {
		this.rno = rno;
	}
    @OneToOne(mappedBy="Department",cascade=CascadeType.ALL)
    @JoinColumn(name="dno")
	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Instructor [i_id=" + i_id + ", iname=" + iname + ", rno=" + rno + ", dept=" + dept + "]";
	}
	

	
	
	
	
	

}

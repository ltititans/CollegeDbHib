package com.lti.implc;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.lti.college.College.Department;
import com.lti.college.College.Instructor;
import com.lti.interfacesp.Crud;

public class InstructorImpl implements Crud{

	public void insert() {
		// TODO Auto-generated method stub
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		Scanner sc=new Scanner(System.in);
		entityManager.getTransaction().begin();
		
		Instructor i = new Instructor();
		System.out.println("enter the Instructor name");
		String iname=sc.next();
		System.out.println("enter the room no");

		int rno=sc.nextInt();
	      i.setIname(iname);
	      i.setRno(rno);
		entityManager.persist(i);
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	public void delete() {
		// TODO Auto-generated method stub
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		Instructor i = new Instructor();
	}

	public void retreive() {
		// TODO Auto-generated method stub
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		Instructor i = new Instructor();
		Query query = entityManager.createQuery("from Instructor where i_id = '2' ");
        List<Instructor> list = query.getResultList();
        Iterator it =list.iterator();
        while(it.hasNext())
        {
        	System.out.println(it.next());
        }
        entityManager.getTransaction().commit();
        entityManager.close();
	}

	public void update() {
		// TODO Auto-generated method stub
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		Instructor i = new Instructor();
	}

}

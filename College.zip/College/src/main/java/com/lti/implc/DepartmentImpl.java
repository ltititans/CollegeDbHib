package com.lti.implc;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.lti.college.College.Department;
import com.lti.interfacesp.Crud;

public class DepartmentImpl implements Crud {

	public void insert() {
		// TODO Auto-generated method stub
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Starting transaction");
		Scanner sc=new Scanner(System.in);
		entityManager.getTransaction().begin();
		Department d= new Department();
		System.out.println("enter the department name");
		String dname=sc.next();
		System.out.println("enter the department location");

		String dloc=sc.next();
		d.setDname(dname);
		d.setDloc(dloc);
		entityManager.persist(d);
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	public void delete() {
		// TODO Auto-generated method stub
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
//		Query query = entityManager.createQuery("delete department where dno = :dno");
//		query.setParameter("dno", "2");
//		int result = query.executeUpdate();
//		System.out.println("enter id");
//		Scanner in=new Scanner(System.in);
//		int n=in.nextInt();
		Department d=new Department();
		int d1=d.getDno();
		 Department d2 = entityManager.find(Department.class, d1);
	       
	       
	        entityManager.remove(d2);
	        entityManager.getTransaction().commit();
	        entityManager.close();

	
	}

	public void retreive() {
		// TODO Auto-generated method stub
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

        entityManager.getTransaction().begin();
        Department d=new Department();
        Query query = entityManager.createQuery("from Department where dno = '2' ");
        List<Department> list = query.getResultList();
        Iterator it =list.iterator();
        while(it.hasNext())
        {
        	System.out.println(it.next());
        }
        entityManager.getTransaction().commit();
        entityManager.close();
	}

	public void update() {
		// TODO Auto-generated method stub
		EntityManagerFactory  entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
	
		Query query = entityManager.createQuery("update Department set dname = :dName" +
				" where dno = :dno");
query.setParameter("dName", "km");
query.setParameter("dno", 2);
 query.executeUpdate();
		 //Department d = new Department();
//		 System.out.println("Department id :: " + d.getDno());
//	        System.out.println("Department Name :: " + d.getDname());
//	        System.out.println("Department Location :: " + d.getDloc());
//	        
//	        Scanner sc=new Scanner(System.in);
//	        System.out.println("enter the department number");
//		int  dno=sc.nextInt();
			
			
			
//	        System.out.println("enter the department name");
//			String dname=sc.next();
//			System.out.println("enter the department location");
//			String dloc=sc.next();
//			d.setDno(dno);
//			d.setDloc(dloc);
//            d.setDname(dname);
           // entityManager.merge(d);
          
            entityManager.getTransaction().commit();
            entityManager.close();
            

	}

}

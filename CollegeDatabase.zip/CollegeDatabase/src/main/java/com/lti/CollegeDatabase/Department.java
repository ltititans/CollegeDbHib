package com.lti.CollegeDatabase;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Department30")
public class Department {
	
	private long dept_id;
	private String dept_name;
	private String location;
	
	
	public Department() {
		
	}
public Department(String dept_name, String location) {
		super();
		this.dept_name = dept_name;
		this.location = location;
		
	}
@Id
@Column(name="Dept_id")
@GeneratedValue(strategy=GenerationType.AUTO,generator="somesequenceName")
@SequenceGenerator(name="somesequenceName",sequenceName="dept_seq20",allocationSize =1)
public long getDept_id() {
	return dept_id;
}

public void setDept_id(long dept_id) {
	this.dept_id = dept_id;
}


@Column(name="Dept_name")
public String getDept_name() {
	return dept_name;
}

public void setDept_name(String dept_name) {
	this.dept_name = dept_name;
}

@Column(name="Dept_location")
public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}

private Set<Instructor> instructors;
@OneToMany(cascade=CascadeType.ALL)
@JoinColumn(name="Dept_id")

public Set<Instructor> getInstructors() {
	return instructors;
}
public void setInstructors(Set<Instructor> instructors) {
	this.instructors = instructors;
}
@Override
public String toString() {
	return "Department [dept_id=" + dept_id + ", dept_name=" + dept_name + ", location=" + location + ", instructors="
			+ instructors + "]";
}

}

